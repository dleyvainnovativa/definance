@php
    $nav = [
        ['section' => null, 'items' => [
            ['route' => 'dashboard', 'label' => 'Resumen', 'icon' => 'grid'],
        ]],
        ['section' => 'Contabilidad', 'items' => [
            ['route' => 'accounts', 'label' => 'Catálogo de cuentas', 'icon' => 'list'],
            ['route' => 'entries', 'label' => 'Pólizas', 'icon' => 'book'],
        ]],
        ['section' => 'Reportes', 'items' => [
            ['route' => 'trial-balance', 'label' => 'Balanza de comprobación', 'icon' => 'scale'],
            ['route' => 'income-statement', 'label' => 'Estado de resultados', 'icon' => 'trend'],
            ['route' => 'balance-sheet', 'label' => 'Balance general', 'icon' => 'layers'],
            ['route' => 'cash-flow', 'label' => 'Flujo de efectivo', 'icon' => 'cash'],
            ['route' => 'iva', 'label' => 'Declaración de IVA', 'icon' => 'percent'],
        ]],
        ['section' => 'Cuenta', 'items' => [
            ['route' => 'profile', 'label' => 'Perfil', 'icon' => 'user'],
        ]],
    ];

    $icons = [
        'grid' => '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
        'list' => '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><circle cx="3.5" cy="6" r="1"/><circle cx="3.5" cy="12" r="1"/><circle cx="3.5" cy="18" r="1"/>',
        'book' => '<path d="M4 4h12a2 2 0 0 1 2 2v14H6a2 2 0 0 1-2-2V4z"/><line x1="8" y1="8" x2="14" y2="8"/>',
        'scale' => '<line x1="12" y1="3" x2="12" y2="21"/><path d="M5 7h14"/><path d="M5 7l-2.5 6a3 3 0 0 0 5 0L5 7z"/><path d="M19 7l-2.5 6a3 3 0 0 0 5 0L19 7z"/>',
        'trend' => '<polyline points="3 17 9 11 13 15 21 7"/><polyline points="15 7 21 7 21 13"/>',
        'layers' => '<polygon points="12 3 21 8 12 13 3 8 12 3"/><polyline points="3 13 12 18 21 13"/>',
        'cash' => '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/>',
        'percent' => '<line x1="19" y1="5" x2="5" y2="19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/>',
        'user' => '<circle cx="12" cy="8" r="3.5"/><path d="M5 20a7 7 0 0 1 14 0"/>',
    ];
@endphp

<aside class="sidebar">
    <div class="brand">
        <span class="mark">D</span> DeFinance
    </div>
    <nav class="nav">
        @foreach ($nav as $group)
            @if ($group['section'])
                <div class="nav-section">{{ $group['section'] }}</div>
            @endif
            @foreach ($group['items'] as $item)
                <a href="{{ route($item['route']) }}"
                   class="nav-link {{ request()->routeIs($item['route']) ? 'active' : '' }}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                         stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        {!! $icons[$item['icon']] !!}
                    </svg>
                    {{ $item['label'] }}
                </a>
            @endforeach
        @endforeach
    </nav>
</aside>
